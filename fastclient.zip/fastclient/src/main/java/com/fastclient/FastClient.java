package com.fastclient;

import com.fastclient.gui.ClickGui;
import com.fastclient.hud.Hud;
import com.fastclient.module.ModuleManager;
import com.fastclient.util.Config;
import com.fastclient.util.Cps;
import com.mojang.blaze3d.platform.InputConstants;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public class FastClient implements ClientModInitializer {
	private static final KeyMapping.Category CATEGORY =
		KeyMapping.Category.register(Identifier.fromNamespaceAndPath("fastclient", "main"));

	public static final KeyMapping OPEN_GUI_KEY = KeyBindingHelper.registerKeyBinding(
		new KeyMapping("key.fastclient.open_gui", InputConstants.KEY_RSHIFT, CATEGORY));
	public static final KeyMapping ZOOM_KEY = KeyBindingHelper.registerKeyBinding(
		new KeyMapping("key.fastclient.zoom", InputConstants.KEY_C, CATEGORY));

	@Override
	public void onInitializeClient() {
		ModuleManager.init();
		Cps.init();
		Hud.init();

		// Modules are loaded once the game is up, because turning one on touches Minecraft options.
		ClientLifecycleEvents.CLIENT_STARTED.register(mc -> Config.load());
		ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> Config.save());

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			while (OPEN_GUI_KEY.consumeClick()) {
				mc.gui.setScreen(new ClickGui(mc.gui.screen()));
			}
			ModuleManager.tick(mc);
		});
	}
}
