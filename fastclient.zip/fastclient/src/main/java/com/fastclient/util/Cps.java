package com.fastclient.util;

import java.util.ArrayDeque;
import java.util.Deque;

import net.fabricmc.fabric.api.client.event.player.ClientPreAttackCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.world.InteractionResult;

/** Clicks-per-second tracking over a rolling one second window. */
public final class Cps {
	private static final Deque<Long> LEFT = new ArrayDeque<>();
	private static final Deque<Long> RIGHT = new ArrayDeque<>();

	private Cps() {}

	public static void init() {
		ClientPreAttackCallback.EVENT.register((mc, player, clickCount) -> {
			LEFT.addLast(System.currentTimeMillis());
			return false; // never cancel the attack
		});
		UseItemCallback.EVENT.register((player, level, hand) -> {
			if (level.isClientSide()) RIGHT.addLast(System.currentTimeMillis());
			return InteractionResult.PASS;
		});
		UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
			if (level.isClientSide()) RIGHT.addLast(System.currentTimeMillis());
			return InteractionResult.PASS;
		});
	}

	public static int left() {
		return count(LEFT);
	}

	public static int right() {
		return count(RIGHT);
	}

	private static int count(Deque<Long> clicks) {
		long cutoff = System.currentTimeMillis() - 1000;
		while (!clicks.isEmpty() && clicks.peekFirst() < cutoff) clicks.pollFirst();
		return clicks.size();
	}
}
