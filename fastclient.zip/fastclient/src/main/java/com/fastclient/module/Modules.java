package com.fastclient.module;

import java.util.HashMap;
import java.util.Map;

import com.fastclient.FastClient;
import com.fastclient.util.Config;

import net.minecraft.client.CloudStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.Options;
import net.minecraft.client.ParticleStatus;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/** Behaviour modules. Each is a small self-contained class. */
final class Modules {
	private Modules() {}

	/** Lowers expensive video settings and removes the FPS cap. Restores the old values when turned off. */
	static final class FpsBoost extends Module {
		private final Map<String, Object> saved = new HashMap<>();

		FpsBoost() {
			super("FPS Boost", "Lower render distance, minimal particles, no clouds, no vsync, uncapped FPS", Category.PERFORMANCE);
		}

		@Override
		protected void onEnable(Minecraft mc) {
			Options o = mc.options;
			set(o.renderDistance(), 8, "rd");
			set(o.simulationDistance(), 6, "sim");
			set(o.particles(), ParticleStatus.MINIMAL, "particles");
			set(o.cloudStatus(), CloudStatus.OFF, "clouds");
			set(o.entityShadows(), false, "shadows");
			set(o.biomeBlendRadius(), 0, "biome");
			set(o.mipmapLevels(), 0, "mip");
			set(o.enableVsync(), false, "vsync");
			set(o.framerateLimit(), 260, "fps");
			set(o.entityDistanceScaling(), 0.75, "entityDist");
			set(o.ambientOcclusion(), false, "ao");
		}

		@Override
		protected void onDisable(Minecraft mc) {
			Options o = mc.options;
			restore(o.renderDistance(), "rd");
			restore(o.simulationDistance(), "sim");
			restore(o.particles(), "particles");
			restore(o.cloudStatus(), "clouds");
			restore(o.entityShadows(), "shadows");
			restore(o.biomeBlendRadius(), "biome");
			restore(o.mipmapLevels(), "mip");
			restore(o.enableVsync(), "vsync");
			restore(o.framerateLimit(), "fps");
			restore(o.entityDistanceScaling(), "entityDist");
			restore(o.ambientOcclusion(), "ao");
			saved.clear();
		}

		private <T> void set(OptionInstance<T> option, T value, String key) {
			saved.putIfAbsent(key, option.get());
			option.set(value);
		}

		@SuppressWarnings("unchecked")
		private <T> void restore(OptionInstance<T> option, String key) {
			Object old = saved.get(key);
			if (old != null) option.set((T) old);
		}
	}

	/**
	 * Directional blur that kicks in while you turn the camera quickly. It swaps between three vanilla post-effect chains
	 * (see assets/fastclient/post_effect) based on rotation speed, so it needs no custom shader code.
	 */
	static final class MotionBlur extends Module {
		private static final Identifier[] CHAINS = {
			Identifier.fromNamespaceAndPath("fastclient", "motion_blur_low"),
			Identifier.fromNamespaceAndPath("fastclient", "motion_blur_medium"),
			Identifier.fromNamespaceAndPath("fastclient", "motion_blur_high"),
		};
		private static final float TURN_THRESHOLD = 4.0f; // degrees per tick
		private float lastYaw, lastPitch;
		private int active = -1;
		private int calmTicks;

		MotionBlur() {
			super("Motion Blur", "Blur while turning fast. Strength is set in the GUI", Category.VISUAL);
		}

		@Override
		public void onTick(Minecraft mc) {
			if (mc.player == null) return;
			float yaw = mc.player.getYRot(), pitch = mc.player.getXRot();
			float speed = Math.abs(Mth.wrapDegrees(yaw - lastYaw)) + Math.abs(pitch - lastPitch);
			lastYaw = yaw;
			lastPitch = pitch;

			if (speed > TURN_THRESHOLD) {
				calmTicks = 0;
				if (active != Config.blurStrength) {
					mc.gameRenderer.setPostEffect(CHAINS[Config.blurStrength]);
					active = Config.blurStrength;
				}
			} else if (active != -1 && ++calmTicks > 3) {
				clear(mc);
			}
		}

		@Override
		protected void onDisable(Minecraft mc) {
			clear(mc);
		}

		private void clear(Minecraft mc) {
			mc.gameRenderer.clearPostEffect();
			active = -1;
		}
	}

	/** Hold the zoom key to drop FOV to 30, release to restore it. No mixin needed. */
	static final class Zoom extends Module {
		private boolean zooming;
		private int savedFov;

		Zoom() {
			super("Zoom", "Hold C to zoom", Category.VISUAL);
		}

		@Override
		public void onTick(Minecraft mc) {
			OptionInstance<Integer> fov = mc.options.fov();
			boolean want = FastClient.ZOOM_KEY.isDown() && mc.gui.screen() == null;
			if (want && !zooming) {
				savedFov = fov.get();
				fov.set(30);
				zooming = true;
			} else if (!want && zooming) {
				fov.set(savedFov);
				zooming = false;
			}
		}

		@Override
		protected void onDisable(Minecraft mc) {
			if (zooming) {
				mc.options.fov().set(savedFov);
				zooming = false;
			}
		}
	}

	/** Re-applies a hidden client-side night vision effect each tick. */
	static final class Fullbright extends Module {
		Fullbright() {
			super("Fullbright", "See in the dark", Category.VISUAL);
		}

		@Override
		public void onTick(Minecraft mc) {
			if (mc.player != null) {
				mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false));
			}
		}

		@Override
		protected void onDisable(Minecraft mc) {
			if (mc.player != null) mc.player.removeEffect(MobEffects.NIGHT_VISION);
		}
	}

	/** Holds sprint for you while you move forward. */
	static final class ToggleSprint extends Module {
		ToggleSprint() {
			super("Toggle Sprint", "Sprint automatically while moving forward", Category.UTILITY);
		}

		@Override
		public void onTick(Minecraft mc) {
			if (mc.player != null && mc.options.keyUp.isDown() && !mc.player.isShiftKeyDown()) {
				mc.options.keySprint.setDown(true);
			}
		}
	}

	/** Pure flag modules: the HUD checks isEnabled() to draw them. */
	static final class HudFlag extends Module {
		HudFlag(String name, String description) {
			super(name, description, Category.COUNTERS);
		}
	}
}
