package com.fastclient.hud;

import com.fastclient.module.CounterModule;
import com.fastclient.module.Module;
import com.fastclient.module.ModuleManager;
import com.fastclient.util.Cps;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

public final class Hud {
	private static final int BG = 0x90000000;
	private static final int BG_ON = 0xB0FFFFFF;
	private static final int ACCENT = 0xFF55FFAA;
	private static final EquipmentSlot[] ARMOR = {
		EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
	};

	private Hud() {}

	public static void init() {
		HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("fastclient", "hud"), Hud::extract);
	}

	private static void extract(GuiGraphicsExtractor g, DeltaTracker delta) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null || mc.options.hideGui) return;
		Font font = mc.font;

		counters(g, mc, font);
		if (ModuleManager.on("Keystrokes")) keystrokes(g, mc, font);
		if (ModuleManager.on("Armor Status")) armor(g, mc, font);
	}

	/** Counter lines stacked in the top-left corner on one translucent panel. */
	private static void counters(GuiGraphicsExtractor g, Minecraft mc, Font font) {
		java.util.List<String> lines = new java.util.ArrayList<>();
		for (Module m : ModuleManager.all()) {
			if (m instanceof CounterModule c && c.isEnabled()) lines.add(c.line(mc));
		}
		if (lines.isEmpty()) return;

		int width = 0;
		for (String s : lines) width = Math.max(width, font.width(s));
		int x = 4, y = 4, h = lines.size() * 11 + 4;
		g.fill(x, y, x + width + 8, y + h, BG);
		g.fill(x, y, x + 2, y + h, ACCENT);
		int ty = y + 3;
		for (String s : lines) {
			g.text(font, s, x + 6, ty, 0xFFFFFFFF);
			ty += 11;
		}
	}

	/** WASD cluster, jump bar and mouse buttons with live CPS, bottom-left. */
	private static void keystrokes(GuiGraphicsExtractor g, Minecraft mc, Font font) {
		int size = 20, gap = 2;
		int x0 = 6, y0 = g.guiHeight() - 4 * (size + gap) - 6;
		key(g, font, mc.options.keyUp, "W", x0 + size + gap, y0, size, size);
		key(g, font, mc.options.keyLeft, "A", x0, y0 + size + gap, size, size);
		key(g, font, mc.options.keyDown, "S", x0 + size + gap, y0 + size + gap, size, size);
		key(g, font, mc.options.keyRight, "D", x0 + 2 * (size + gap), y0 + size + gap, size, size);

		int wide = (size * 3 + gap * 2 - gap) / 2;
		key(g, font, mc.options.keyAttack, "LMB " + Cps.left(), x0, y0 + 2 * (size + gap), wide, size);
		key(g, font, mc.options.keyUse, "RMB " + Cps.right(), x0 + wide + gap, y0 + 2 * (size + gap), wide, size);
		key(g, font, mc.options.keyJump, "SPACE", x0, y0 + 3 * (size + gap), size * 3 + gap * 2, 12);
	}

	private static void key(GuiGraphicsExtractor g, Font font, KeyMapping key, String label, int x, int y, int w, int h) {
		boolean down = key.isDown();
		g.fill(x, y, x + w, y + h, down ? BG_ON : BG);
		int tx = x + (w - font.width(label)) / 2;
		int ty = y + (h - 8) / 2;
		g.text(font, label, tx, ty, down ? 0xFF000000 : 0xFFFFFFFF);
	}

	/** Armor pieces with remaining durability, bottom-right above the hotbar edge. */
	private static void armor(GuiGraphicsExtractor g, Minecraft mc, Font font) {
		int x = g.guiWidth() - 60;
		int y = g.guiHeight() - 4 * 18 - 30;
		for (EquipmentSlot slot : ARMOR) {
			ItemStack stack = mc.player.getItemBySlot(slot);
			if (!stack.isEmpty()) {
				g.item(stack, x, y);
				if (stack.isDamageableItem()) {
					String left = String.valueOf(stack.getMaxDamage() - stack.getDamageValue());
					g.text(font, left, x + 20, y + 4, 0xFFFFFFFF);
				}
			}
			y += 18;
		}
		ItemStack hand = mc.player.getMainHandItem();
		if (!hand.isEmpty() && hand.isDamageableItem()) {
			g.item(hand, x, y);
			g.text(font, String.valueOf(hand.getMaxDamage() - hand.getDamageValue()), x + 20, y + 4, 0xFFFFFFFF);
		}
	}
}
