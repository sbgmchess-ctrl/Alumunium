package com.fastclient.util;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

import com.fastclient.module.Module;
import com.fastclient.module.ModuleManager;

import net.fabricmc.loader.api.FabricLoader;

/** Saves which modules are on, plus the motion blur strength, to config/fastclient.properties. */
public final class Config {
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("fastclient.properties");

	/** 0 = low, 1 = medium, 2 = high. */
	public static int blurStrength = 1;

	private Config() {}

	public static void load() {
		Properties p = new Properties();
		if (Files.exists(FILE)) {
			try (Reader r = Files.newBufferedReader(FILE)) {
				p.load(r);
			} catch (IOException ignored) {}
		}
		blurStrength = Math.max(0, Math.min(2, Integer.parseInt(p.getProperty("blurStrength", "1"))));
		for (Module m : ModuleManager.all()) {
			m.setEnabled(Boolean.parseBoolean(p.getProperty("module." + m.name, String.valueOf(defaultOn(m)))));
		}
	}

	public static void save() {
		Properties p = new Properties();
		p.setProperty("blurStrength", String.valueOf(blurStrength));
		for (Module m : ModuleManager.all()) p.setProperty("module." + m.name, String.valueOf(m.isEnabled()));
		try (Writer w = Files.newBufferedWriter(FILE)) {
			p.store(w, "Fast Client");
		} catch (IOException ignored) {}
	}

	private static boolean defaultOn(Module m) {
		return switch (m.name) {
			case "FPS Boost", "FPS", "CPS", "Ping", "Coordinates", "Keystrokes", "Armor Status", "Zoom", "Toggle Sprint" -> true;
			default -> false;
		};
	}
}
