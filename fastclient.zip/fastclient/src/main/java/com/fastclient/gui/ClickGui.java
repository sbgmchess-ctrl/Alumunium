package com.fastclient.gui;

import java.util.ArrayList;
import java.util.List;

import com.fastclient.module.Module;
import com.fastclient.module.ModuleManager;
import com.fastclient.util.Config;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * The client menu. Modules are grouped by category into columns, each a toggle button.
 * Built from vanilla widgets so mouse and keyboard input keep working across Minecraft's input changes (SDL in 26.3).
 */
public class ClickGui extends Screen {
	private static final int COL_W = 112, GAP = 8, BTN_H = 20, ROW = 22, TOP = 44;
	private static final String[] BLUR_LABELS = { "Low", "Medium", "High" };

	private record Column(String title, int x) {}

	private final List<Column> columns = new ArrayList<>();
	private final Screen parent;

	public ClickGui(Screen parent) {
		super(Component.literal("Fast Client"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		columns.clear();
		int perColumn = Math.max(3, (this.height - TOP - 40) / ROW);

		// Work out the column layout first so the whole thing can be centred.
		List<List<Module>> groups = new ArrayList<>();
		List<String> titles = new ArrayList<>();
		for (Module.Category cat : Module.Category.values()) {
			List<Module> inCat = ModuleManager.all().stream().filter(m -> m.category == cat).toList();
			for (int i = 0; i < inCat.size(); i += perColumn) {
				groups.add(inCat.subList(i, Math.min(inCat.size(), i + perColumn)));
				titles.add(i == 0 ? cat.label : cat.label + " (cont.)");
			}
		}
		int totalW = groups.size() * COL_W + (groups.size() - 1) * GAP;
		int x = (this.width - totalW) / 2;

		for (int c = 0; c < groups.size(); c++) {
			columns.add(new Column(titles.get(c), x));
			int y = TOP;
			for (Module m : groups.get(c)) {
				Button b = Button.builder(label(m), btn -> {
					m.toggle();
					btn.setMessage(label(m));
					Config.save();
				}).bounds(x, y, COL_W, BTN_H).tooltip(net.minecraft.client.gui.components.Tooltip.create(Component.literal(m.description))).build();
				this.addRenderableWidget(b);
				y += ROW;
			}
			x += COL_W + GAP;
		}

		// Motion blur strength cycler and Done button along the bottom.
		int bottom = this.height - 28;
		this.addRenderableWidget(Button.builder(blurLabel(), btn -> {
			Config.blurStrength = (Config.blurStrength + 1) % 3;
			btn.setMessage(blurLabel());
			Config.save();
		}).bounds(this.width / 2 - 154, bottom, 150, BTN_H).build());

		this.addRenderableWidget(Button.builder(Component.literal("Done"), btn -> this.onClose())
			.bounds(this.width / 2 + 4, bottom, 150, BTN_H).build());
	}

	private static Component label(Module m) {
		return Component.literal(m.name + ": " + (m.isEnabled() ? "ON" : "OFF"))
			.withColor(m.isEnabled() ? 0x55FFAA : 0xFF7777);
	}

	private static Component blurLabel() {
		return Component.literal("Motion Blur strength: " + BLUR_LABELS[Config.blurStrength]);
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		super.extractRenderState(g, mouseX, mouseY, delta);
		g.centeredText(this.font, "Fast Client", this.width / 2, 12, 0xFF55FFAA);
		g.centeredText(this.font, "Right Shift to open, click a module to toggle", this.width / 2, 26, 0xFFAAAAAA);
		for (Column col : columns) {
			g.fill(col.x(), TOP - 4, col.x() + COL_W, TOP - 3, 0xFF55FFAA);
			g.text(this.font, col.title(), col.x(), TOP - 14, 0xFFFFFFFF);
		}
	}

	@Override
	public void onClose() {
		this.minecraft.gui.setScreen(parent);
	}
}
