package com.fastclient.module;

import java.util.function.Function;

import net.minecraft.client.Minecraft;

/** A HUD counter: one line of text, rendered by {@link com.fastclient.hud.Hud}. */
public class CounterModule extends Module {
	private final Function<Minecraft, String> text;

	public CounterModule(String name, Function<Minecraft, String> text) {
		super(name, "Shows " + name + " on the HUD", Category.COUNTERS);
		this.text = text;
	}

	public String line(Minecraft mc) {
		try {
			return text.apply(mc);
		} catch (RuntimeException e) {
			return name + ": -";
		}
	}
}
