# Fast Client (Fabric, Minecraft 26.3)

Client-side Fabric mod: FPS boost, motion blur, zoom, fullbright, toggle sprint, 11 HUD counters,
keystrokes, armor status and a click GUI. No server-side parts, no combat or movement cheats.

## Build
Requires JDK 25 and Gradle 9.6.0 (Loom 1.17).

    gradle wrapper --gradle-version 9.6.0   # once, generates ./gradlew
    ./gradlew build

The jar is `build/libs/fastclient-1.0.0.jar`. Put it in `.minecraft/mods` with
Fabric Loader 0.19.5+ and Fabric API 0.166.2+26.3 (or newer 26.3 build).

## Use
- **Right Shift**: open the menu. Click a module to toggle it; hover for a description.
- **C** (hold): zoom.
- Settings save to `config/fastclient.properties`. Rebind keys in Controls > Fast Client.

## Features
| Category | Modules |
|---|---|
| Performance | FPS Boost (render/sim distance, particles, clouds, shadows, biome blend, mipmaps, AO, vsync, uncapped FPS; old values restored when off) |
| Visual | Motion Blur (Low/Medium/High, kicks in while turning), Zoom, Fullbright |
| Utility | Toggle Sprint |
| Counters | FPS, CPS (left/right), Ping, Coordinates, Chunk, Facing, Speed, Memory, Clock, Day, Light, Keystrokes, Armor Status |

## Known risks (written without a compiler against 26.3)
Minecraft 26.x renamed a lot of GUI and options classes. These are the likeliest spots to need a one-line fix:
- `Options` accessors in `Modules.FpsBoost` (e.g. `ambientOcclusion()`, `entityDistanceScaling()`).
- `GameRenderer.setPostEffect` / `clearPostEffect` in `Modules.MotionBlur`.
- `GuiGraphicsExtractor.text / fill / item / centeredText / guiWidth` in `Hud` and `ClickGui`.
- `Screen.extractRenderState`, `Minecraft.gui.setScreen/screen()` in `ClickGui` and `FastClient`.
- Motion blur reuses vanilla `minecraft:post/blur` with uniform block `BlurConfig`; if the uniform names differ in 26.3, edit the three JSON files in `assets/fastclient/post_effect`.
