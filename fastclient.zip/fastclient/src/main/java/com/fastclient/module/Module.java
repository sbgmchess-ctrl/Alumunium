package com.fastclient.module;

import net.minecraft.client.Minecraft;

public abstract class Module {
	public enum Category {
		PERFORMANCE("Performance"), VISUAL("Visual"), UTILITY("Utility"), COUNTERS("Counters");

		public final String label;

		Category(String label) {
			this.label = label;
		}
	}

	public final String name;
	public final String description;
	public final Category category;
	private boolean enabled;

	protected Module(String name, String description, Category category) {
		this.name = name;
		this.description = description;
		this.category = category;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void toggle() {
		setEnabled(!enabled);
	}

	public void setEnabled(boolean value) {
		if (value == enabled) return;
		enabled = value;
		Minecraft mc = Minecraft.getInstance();
		if (value) onEnable(mc); else onDisable(mc);
	}

	protected void onEnable(Minecraft mc) {}

	protected void onDisable(Minecraft mc) {}

	public void onTick(Minecraft mc) {}
}
