package com.fastclient.module;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.fastclient.util.Cps;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.core.BlockPos;

public final class ModuleManager {
	private static final List<Module> MODULES = new ArrayList<>();
	private static final Runtime RT = Runtime.getRuntime();

	private ModuleManager() {}

	public static void init() {
		// Performance and visual/utility modules
		add(new Modules.FpsBoost());
		add(new Modules.MotionBlur());
		add(new Modules.Zoom());
		add(new Modules.Fullbright());
		add(new Modules.ToggleSprint());

		// Counters (one line each on the HUD)
		add(new CounterModule("FPS", mc -> mc.getFps() + " FPS"));
		add(new CounterModule("CPS", mc -> "CPS " + Cps.left() + " | " + Cps.right()));
		add(new CounterModule("Ping", mc -> {
			if (mc.player == null || mc.getConnection() == null) return "Ping -";
			PlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
			return info == null ? "Ping -" : "Ping " + info.getLatency() + " ms";
		}));
		add(new CounterModule("Coordinates", mc -> String.format(Locale.ROOT, "XYZ %.1f / %.1f / %.1f",
			mc.player.getX(), mc.player.getY(), mc.player.getZ())));
		add(new CounterModule("Chunk", mc -> "Chunk " + (mc.player.blockPosition().getX() >> 4) + ", " + (mc.player.blockPosition().getZ() >> 4)));
		add(new CounterModule("Facing", mc -> "Facing " + mc.player.getDirection().getName()
			+ String.format(Locale.ROOT, " (%.0f)", net.minecraft.util.Mth.wrapDegrees(mc.player.getYRot()))));
		add(new CounterModule("Speed", mc -> {
			double dx = mc.player.getX() - mc.player.xo, dz = mc.player.getZ() - mc.player.zo;
			return String.format(Locale.ROOT, "Speed %.2f b/s", Math.sqrt(dx * dx + dz * dz) * 20);
		}));
		add(new CounterModule("Memory", mc -> {
			long used = (RT.totalMemory() - RT.freeMemory()) / 1048576L;
			return "Mem " + used + "/" + (RT.maxMemory() / 1048576L) + " MB";
		}));
		add(new CounterModule("Clock", mc -> java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss"))));
		add(new CounterModule("Day", mc -> "Day " + (mc.level.getDayTime() / 24000L)));
		add(new CounterModule("Light", mc -> {
			BlockPos pos = mc.player.blockPosition();
			return "Light " + mc.level.getMaxLocalRawBrightness(pos);
		}));

		// HUD widgets drawn by Hud itself
		add(new Modules.HudFlag("Keystrokes", "WASD, jump and mouse buttons"));
		add(new Modules.HudFlag("Armor Status", "Armor pieces and durability"));
	}

	private static void add(Module m) {
		MODULES.add(m);
	}

	public static List<Module> all() {
		return MODULES;
	}

	public static Module get(String name) {
		for (Module m : MODULES) if (m.name.equals(name)) return m;
		throw new IllegalArgumentException(name);
	}

	public static boolean on(String name) {
		return get(name).isEnabled();
	}

	public static void tick(Minecraft mc) {
		for (Module m : MODULES) if (m.isEnabled()) m.onTick(mc);
	}
}
